"""
M1 — Python Otomasyon Refleksleri
Reference solution: a SQLite-backed CLI todo tool.

Public API (used by tests):
    DB_PATH = "tasks.db"            # default location, overridable via env var

    init_db(path: str) -> None      # create the schema if it doesn't exist
    add_task(title: str, path: str) -> int     # insert, return new task id
    list_tasks(path: str) -> list[dict]        # ordered by id ascending
    complete_task(id: int, path: str) -> bool  # mark done, return True if found
    build_parser() -> argparse.ArgumentParser  # CLI parser (also used in tests)

CLI usage:
    python tool.py --add "Toplantıyı planla"
    python tool.py --list
    python tool.py --complete 3

Environment variables:
    TODO_DB_PATH    Override the SQLite file location (defaults to tasks.db
                    in the current directory).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sqlite3
import sys
from typing import Optional


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_DB_PATH = os.environ.get("TODO_DB_PATH", "tasks.db")

logger = logging.getLogger("todo")


# ---------------------------------------------------------------------------
# Database layer
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


def _connect(path: str) -> sqlite3.Connection:
    """Open a connection with row_factory set to sqlite3.Row for dict-like access."""
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(path: str = DEFAULT_DB_PATH) -> None:
    """Create the tasks table if it doesn't exist. Safe to call repeatedly."""
    with _connect(path) as conn:
        conn.executescript(SCHEMA)


def add_task(title: str, path: str = DEFAULT_DB_PATH) -> int:
    """Insert a task and return its new id.

    Empty or whitespace-only titles are rejected with a ValueError.
    """
    if not title or not title.strip():
        raise ValueError("title must not be empty")

    init_db(path)
    with _connect(path) as conn:
        cur = conn.execute(
            "INSERT INTO tasks (title) VALUES (?)",
            (title.strip(),),
        )
        return cur.lastrowid


def list_tasks(path: str = DEFAULT_DB_PATH) -> list[dict]:
    """Return all tasks ordered by id ascending."""
    init_db(path)
    with _connect(path) as conn:
        rows = conn.execute(
            "SELECT id, title, done, created_at FROM tasks ORDER BY id ASC"
        ).fetchall()
    return [
        {
            "id": row["id"],
            "title": row["title"],
            "done": bool(row["done"]),
            "created_at": row["created_at"],
        }
        for row in rows
    ]


def complete_task(task_id: int, path: str = DEFAULT_DB_PATH) -> bool:
    """Mark a task as done. Returns True if a task was updated, False if no
    row with the given id exists."""
    init_db(path)
    with _connect(path) as conn:
        cur = conn.execute(
            "UPDATE tasks SET done = 1 WHERE id = ?",
            (task_id,),
        )
        return cur.rowcount > 0


# ---------------------------------------------------------------------------
# CLI layer
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    """Construct the argparse parser. Exposed as a function so tests can
    inspect the parser without invoking the program."""
    parser = argparse.ArgumentParser(
        prog="todo",
        description="Yerel bir SQLite veritabanına görev ekleyip listeleyen CLI aracı.",
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--add",
        metavar="TITLE",
        help="Yeni görev ekle. Başlık tırnak içinde verilebilir.",
    )
    group.add_argument(
        "--list",
        action="store_true",
        help="Tüm görevleri JSON dizisi olarak yazdır.",
    )
    group.add_argument(
        "--complete",
        metavar="ID",
        type=int,
        help="Verilen id'li görevi tamamlandı olarak işaretle.",
    )
    parser.add_argument(
        "--db",
        default=DEFAULT_DB_PATH,
        help=f"SQLite dosya yolu (varsayılan: {DEFAULT_DB_PATH})",
    )
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    """Entry point. Returns the process exit code."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
    )

    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.add is not None:
            new_id = add_task(args.add, args.db)
            print(json.dumps({"id": new_id, "title": args.add.strip()}, ensure_ascii=False))
            return 0

        if args.list:
            tasks = list_tasks(args.db)
            print(json.dumps(tasks, ensure_ascii=False, indent=2))
            return 0

        if args.complete is not None:
            ok = complete_task(args.complete, args.db)
            if not ok:
                print(
                    json.dumps(
                        {"error": f"id {args.complete} bulunamadı"},
                        ensure_ascii=False,
                    ),
                    file=sys.stderr,
                )
                return 1
            print(json.dumps({"id": args.complete, "done": True}, ensure_ascii=False))
            return 0

    except ValueError as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2
    except sqlite3.Error as e:
        logger.exception("Database error")
        print(json.dumps({"error": f"db error: {e}"}, ensure_ascii=False), file=sys.stderr)
        return 3

    return 0


if __name__ == "__main__":
    sys.exit(main())
