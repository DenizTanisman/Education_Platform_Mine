"""
M0 — Geliştirme Ortamı ve Python Temelleri
Reference solution.

This file is what a student should produce at the end of Module 0.
It demonstrates the three required functions: selamla, topla, cift_say.
"""


def selamla(isim: str) -> str:
    """Return a personalized Turkish greeting.

    Empty or whitespace-only names should produce 'Merhaba!' so the
    function is robust to trivial input.

    Args:
        isim: The name to greet.

    Returns:
        A greeting string.
    """
    if not isim or not isim.strip():
        return "Merhaba!"
    return f"Merhaba, {isim}!"


def topla(sayilar: list[int]) -> int:
    """Return the sum of a list of integers.

    An empty list returns 0 (the additive identity), matching Python's
    built-in sum() semantics.

    Args:
        sayilar: A list of integers (may be empty).

    Returns:
        The sum of all elements.
    """
    total = 0
    for sayi in sayilar:
        total += sayi
    return total


def cift_say(sayilar: list[int]) -> int:
    """Count how many integers in the list are even.

    Zero is considered even. Negative numbers follow the same parity rule
    as positive ones (e.g. -4 is even).

    Args:
        sayilar: A list of integers (may be empty).

    Returns:
        The count of even numbers.
    """
    count = 0
    for sayi in sayilar:
        if sayi % 2 == 0:
            count += 1
    return count
