"""
M3 — LLM SDK ile Doğrudan Bağlantı
Reference solution: an async parallel title summarizer.

Public API (used by tests):
    summarize_one(title: str, client) -> str
        Single async LLM call. Returns the summary string.

    summarize_many(titles: list[str], client, max_concurrency: int = 5) -> list[str]
        Run summarize_one for each title concurrently. Preserves input order.

    save_summaries(titles: list[str], summaries: list[str], path: str) -> None
        Write paired (title, summary) records as JSON.

    build_client(api_key: str | None = None) -> AsyncOpenAI
        Build an AsyncOpenAI client. Reads OPENAI_API_KEY from env if not given.

CLI usage:
    python summarizer.py --input titles.txt --output summaries.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import time
from typing import Optional

from openai import AsyncOpenAI


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_MAX_CONCURRENCY = 5
DEFAULT_MAX_TOKENS = 100
DEFAULT_TEMPERATURE = 0.3   # low temperature => more deterministic summaries

SYSTEM_PROMPT = (
    "Sen kısa, net özetler yazan bir asistansın. "
    "Verilen başlık için 1-2 cümlelik Türkçe özet üret. "
    "Format: yalnızca özet metni, başka açıklama veya markdown kullanma."
)

logger = logging.getLogger("summarizer")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class SummarizeError(Exception):
    """Raised when summarization fails for any reason."""
    pass


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    """Build an AsyncOpenAI client.

    Resolution order for api_key:
      1. Explicit parameter
      2. OPENAI_API_KEY environment variable
      3. ValueError

    Tests inject a mock client directly and don't call this function.
    """
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError(
            "OPENAI_API_KEY is required. "
            "Set it as an environment variable or pass api_key explicitly."
        )
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# Single LLM call
# ---------------------------------------------------------------------------

async def summarize_one(
    title: str,
    client,
    model: str = DEFAULT_MODEL,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    temperature: float = DEFAULT_TEMPERATURE,
) -> str:
    """Summarize a single title via the chat completions API.

    Returns:
        The summary text (stripped of leading/trailing whitespace).

    Raises:
        ValueError: If title is empty.
        SummarizeError: If the API call fails or returns an unexpected shape.
    """
    if not title or not title.strip():
        raise ValueError("title must not be empty")

    try:
        response = await client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Başlık: {title.strip()}"},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
    except Exception as e:
        raise SummarizeError(
            f"API call failed for title {title!r}: {e}"
        ) from e

    try:
        content = response.choices[0].message.content
    except (AttributeError, IndexError) as e:
        raise SummarizeError(
            f"Unexpected response shape for title {title!r}: {e}"
        ) from e

    if content is None:
        raise SummarizeError(
            f"API returned empty content for title {title!r}"
        )

    return content.strip()


# ---------------------------------------------------------------------------
# Parallel orchestration
# ---------------------------------------------------------------------------

async def summarize_many(
    titles: list[str],
    client,
    max_concurrency: int = DEFAULT_MAX_CONCURRENCY,
    **kwargs,
) -> list[str]:
    """Summarize many titles concurrently.

    Returns a list of summaries in the SAME ORDER as the input titles.
    Concurrency is capped by an asyncio.Semaphore so we don't fire all
    requests at once and trip rate limits.

    If any single summarization fails, SummarizeError is raised with the
    failing title surfaced (other in-flight tasks are cancelled).
    """
    if not titles:
        return []

    semaphore = asyncio.Semaphore(max_concurrency)

    async def _bounded(title: str) -> str:
        async with semaphore:
            return await summarize_one(title, client, **kwargs)

    # gather preserves order matching the awaitable list
    tasks = [_bounded(t) for t in titles]
    return await asyncio.gather(*tasks)


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def save_summaries(
    titles: list[str],
    summaries: list[str],
    path: str,
) -> None:
    """Write paired (title, summary) records as JSON."""
    if len(titles) != len(summaries):
        raise ValueError(
            f"titles ({len(titles)}) and summaries ({len(summaries)}) "
            "must be the same length"
        )

    records = [
        {"title": t, "summary": s}
        for t, s in zip(titles, summaries)
    ]

    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="summarizer",
        description="Bir başlık listesini paralel LLM çağrılarıyla özetler.",
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Her satırda bir başlık olan TXT dosyası",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Özetlerin yazılacağı JSON dosyası",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=DEFAULT_MAX_CONCURRENCY,
        help=f"Eşzamanlı istek limiti (varsayılan: {DEFAULT_MAX_CONCURRENCY})",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"OpenAI model adı (varsayılan: {DEFAULT_MODEL})",
    )
    return parser


async def _run(args) -> int:
    # Read titles from input file (one per line, skip blanks)
    with open(args.input, "r", encoding="utf-8") as f:
        titles = [line.strip() for line in f if line.strip()]

    if not titles:
        logger.error("No titles found in %s", args.input)
        return 1

    logger.info(
        "Summarizing %d titles with concurrency=%d, model=%s",
        len(titles), args.concurrency, args.model,
    )

    client = build_client()
    started = time.perf_counter()

    try:
        summaries = await summarize_many(
            titles,
            client,
            max_concurrency=args.concurrency,
            model=args.model,
        )
    except (SummarizeError, ValueError) as e:
        logger.error("Summarization failed: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1

    elapsed = time.perf_counter() - started
    logger.info("Completed %d summaries in %.2fs", len(summaries), elapsed)

    save_summaries(titles, summaries, args.output)
    print(json.dumps({
        "count": len(summaries),
        "elapsed_seconds": round(elapsed, 2),
        "output": args.output,
    }, ensure_ascii=False, indent=2))
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
