"""
M5 — Function Calling ile Tool Kullanımı
Reference solution: a small agent that uses tools.

Public API (used by tests):
    Tool dataclass               — name + schema + callable
    ToolRegistry                 — dict[str, Tool], builds OpenAI tool list
    AgentError (exception)
    GetWeatherInput, CalculateInput  — Pydantic schemas

    run_agent(user_message, client, tool_registry, max_iters=5)
        Run the agent loop. Returns final text response.

The agent loop:
    1. Send user message + tools to LLM
    2. If LLM responds with text -> return it
    3. If LLM responds with tool_calls -> execute each, append results, loop
    4. Stop after max_iters even if not done (safety)

CLI usage:
    python agent.py --message "İstanbul ve Ankara'nın sıcaklık ortalaması nedir?"
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional, Union

from openai import AsyncOpenAI
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_MAX_ITERS = 5
DEFAULT_TEMPERATURE = 0.0

SYSTEM_PROMPT = (
    "Sen kullanıcıya yardımcı olan bir asistansın. "
    "Bilgi gerektiren sorular için gerekli araçları kullan. "
    "Birden fazla araç çağrısı gerekiyorsa hepsini kullan. "
    "Cevaplarını Türkçe ver."
)

logger = logging.getLogger("agent")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class AgentError(Exception):
    """Raised when the agent loop fails."""
    pass


# ---------------------------------------------------------------------------
# Tool schemas (Pydantic input models)
# ---------------------------------------------------------------------------

class GetWeatherInput(BaseModel):
    """Input schema for the get_weather tool."""
    city: str = Field(
        description="Şehir adı, örn: 'İstanbul' veya 'Ankara'",
    )


class CalculateInput(BaseModel):
    """Input schema for the calculate tool."""
    expression: str = Field(
        description="Hesaplanacak matematiksel ifade, örn: '(15 + 12) / 2'",
    )


# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

@dataclass
class Tool:
    """A single callable tool with its schema and Python implementation."""
    name: str
    description: str
    input_schema: type[BaseModel]  # Pydantic class
    handler: Callable[[BaseModel], Awaitable[Any]]  # async callable

    def to_openai_format(self) -> dict:
        """Convert to OpenAI's tools[] entry format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema.model_json_schema(),
            },
        }


@dataclass
class ToolRegistry:
    """A collection of tools indexed by name."""
    tools: dict[str, Tool] = field(default_factory=dict)

    def register(self, tool: Tool) -> None:
        if tool.name in self.tools:
            raise ValueError(f"Tool '{tool.name}' already registered")
        self.tools[tool.name] = tool

    def to_openai_list(self) -> list[dict]:
        """Return all tools in OpenAI's chat.completions tools[] format."""
        return [t.to_openai_format() for t in self.tools.values()]

    async def call(self, name: str, arguments: dict) -> Any:
        """Look up and execute a tool by name."""
        if name not in self.tools:
            raise AgentError(f"Unknown tool: {name}")
        tool = self.tools[name]
        try:
            parsed = tool.input_schema.model_validate(arguments)
        except Exception as e:
            raise AgentError(
                f"Invalid arguments for {name}: {e}"
            ) from e
        return await tool.handler(parsed)


# ---------------------------------------------------------------------------
# Default tool implementations (mocked data — real version would call API)
# ---------------------------------------------------------------------------

# Hardcoded weather data for the reference solution. In a real app this
# would be a network call to OpenWeather, etc.
_MOCK_WEATHER = {
    "istanbul": {"temperature": 15, "condition": "parçalı bulutlu"},
    "ankara": {"temperature": 12, "condition": "açık"},
    "izmir": {"temperature": 19, "condition": "güneşli"},
    "bursa": {"temperature": 14, "condition": "yağmurlu"},
}


async def get_weather_handler(input: GetWeatherInput) -> dict:
    """Look up weather for a city."""
    # Turkish locale: 'İ'.lower() yields 'i̇' (combining dot). Normalize
    # by stripping the combining mark so "İstanbul" matches "istanbul".
    key = input.city.strip().lower().replace("\u0307", "")
    if key not in _MOCK_WEATHER:
        return {"error": f"'{input.city}' için veri yok"}
    data = _MOCK_WEATHER[key]
    return {
        "city": input.city,
        "temperature_celsius": data["temperature"],
        "condition": data["condition"],
    }


# Safe arithmetic evaluator — restrict to basic math operators only.
# eval() is dangerous in general but the universe here is intentionally tiny.
_ALLOWED_NAMES = {"abs": abs, "min": min, "max": max, "round": round}


async def calculate_handler(input: CalculateInput) -> dict:
    """Evaluate a math expression safely."""
    # Whitelist characters so we never execute arbitrary Python.
    safe_chars = set("0123456789+-*/(). %")
    expr = input.expression.strip()
    if not all(c in safe_chars or c.isalpha() for c in expr):
        return {"error": f"Geçersiz karakter ifadede: {expr!r}"}

    try:
        # `__builtins__` boş = sadece _ALLOWED_NAMES çağrılabilir
        result = eval(expr, {"__builtins__": {}}, _ALLOWED_NAMES)
    except Exception as e:
        return {"error": f"Hesaplama hatası: {e.__class__.__name__}: {e}"}

    return {"expression": expr, "result": result}


def build_default_registry() -> ToolRegistry:
    """Build a registry with the two default tools."""
    registry = ToolRegistry()
    registry.register(Tool(
        name="get_weather",
        description="Bir şehir için güncel hava durumunu döndürür",
        input_schema=GetWeatherInput,
        handler=get_weather_handler,
    ))
    registry.register(Tool(
        name="calculate",
        description="Verilen matematiksel ifadeyi hesaplar",
        input_schema=CalculateInput,
        handler=calculate_handler,
    ))
    return registry


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY is required.")
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# Agent loop
# ---------------------------------------------------------------------------

async def run_agent(
    user_message: str,
    client,
    tool_registry: ToolRegistry,
    model: str = DEFAULT_MODEL,
    max_iters: int = DEFAULT_MAX_ITERS,
    temperature: float = DEFAULT_TEMPERATURE,
) -> str:
    """Run the agent loop until the model produces a final text answer.

    Returns the final assistant message content. Raises AgentError if:
      - max_iters exhausted without final answer
      - API call fails
      - tool returns an unknown name
    """
    if not user_message or not user_message.strip():
        raise ValueError("user_message must not be empty")

    messages: list[dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message.strip()},
    ]

    tools = tool_registry.to_openai_list()

    for iteration in range(1, max_iters + 1):
        logger.info("Agent iteration %d/%d", iteration, max_iters)

        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=temperature,
            )
        except Exception as e:
            raise AgentError(f"API call failed: {e}") from e

        message = response.choices[0].message
        tool_calls = message.tool_calls or []

        # No tool calls => model gave a final answer
        if not tool_calls:
            content = message.content
            if content is None:
                raise AgentError("Model returned neither tool calls nor content")
            logger.info("Agent finished after %d iteration(s)", iteration)
            return content.strip()

        # Append the assistant message that contains the tool_calls
        # We must convert it to dict form for the next API call
        messages.append({
            "role": "assistant",
            "content": message.content,  # may be None
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in tool_calls
            ],
        })

        # Execute each tool call (in parallel) and append the results
        async def _execute(tc):
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError as e:
                return tc.id, {"error": f"Argümanlar JSON değil: {e}"}
            try:
                result = await tool_registry.call(tc.function.name, args)
                return tc.id, result
            except AgentError as e:
                return tc.id, {"error": str(e)}

        results = await asyncio.gather(*[_execute(tc) for tc in tool_calls])

        for tool_call_id, result in results:
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": json.dumps(result, ensure_ascii=False),
            })

    raise AgentError(
        f"Agent did not finish within {max_iters} iterations. "
        "Increase max_iters or simplify the task."
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agent",
        description="Hava durumu ve hesap aracı kullanan basit asistan.",
    )
    parser.add_argument(
        "--message",
        required=True,
        help="Asistana sorulacak soru",
    )
    parser.add_argument(
        "--max-iters",
        type=int,
        default=DEFAULT_MAX_ITERS,
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
    )
    return parser


async def _run(args) -> int:
    client = build_client()
    registry = build_default_registry()

    try:
        answer = await run_agent(
            args.message,
            client,
            registry,
            model=args.model,
            max_iters=args.max_iters,
        )
    except (AgentError, ValueError) as e:
        logger.error("Agent failed: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1

    print(json.dumps({"answer": answer}, ensure_ascii=False, indent=2))
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
