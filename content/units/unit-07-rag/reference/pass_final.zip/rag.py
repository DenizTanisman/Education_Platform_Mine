"""
M7 — RAG ile Doküman Tabanlı Asistan
Reference solution: a small RAG system.

Pipeline:
    1. ingest:  document text -> chunks -> embeddings -> RAGStore
    2. query:   user question -> embed -> retrieve top_k chunks -> answer with citations

Public API (used by tests):
    Chunk dataclass             — text, source, chunk_index, embedding (optional)
    RAGStore                    — persistent JSON-backed chunk index

    chunk_text(text, ...) -> list[str]
        Split text into overlapping chunks by character count.

    cosine_similarity(a, b) -> float
        Same as M6.

    get_embedding(text, client) -> list[float]   (async)
        Same shape as M6.

    embed_chunks(chunks, client) -> list[list[float]]   (async, parallel)
        Embed many chunks via asyncio.gather.

    ingest_document(text, source, store, client, ...) -> int   (async)
        End-to-end: chunk, embed, add to store. Returns count of chunks added.

    retrieve(query, store, client, top_k=4) -> list[Chunk]   (async)
        Find the best matching chunks for a query.

    answer_with_rag(query, store, client, ...) -> dict   (async)
        Retrieve chunks, prompt LLM with them, return {answer, citations}.

CLI usage:
    python rag.py --ingest readme.md --store rag.json
    python rag.py --query "RAG nedir?" --store rag.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import math
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Optional

from openai import AsyncOpenAI
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
DEFAULT_CHUNK_SIZE = 800        # characters per chunk
DEFAULT_CHUNK_OVERLAP = 100     # characters of overlap between chunks
DEFAULT_TOP_K = 4
DEFAULT_TEMPERATURE = 0.0

SYSTEM_PROMPT = (
    "Sen verilen kaynak parçalardan yararlanarak soruları cevaplayan bir "
    "asistansın. Sadece sağlanan kaynaklara dayan, bilmediğin şeyi uydurma. "
    "Cevabının sonunda hangi kaynak parçalardan yararlandığını parantez "
    "içinde belirt: (kaynak: chunk #N, dosya: ...). Cevaplarını Türkçe ver."
)

logger = logging.getLogger("rag")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class RAGError(Exception):
    """Raised when RAG operations fail."""
    pass


# ---------------------------------------------------------------------------
# Vector math (same as M6)
# ---------------------------------------------------------------------------

def cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        raise ValueError(f"Vector lengths differ: {len(a)} vs {len(b)}")
    if not a:
        raise ValueError("Vectors must not be empty")

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def get_embedding(
    text: str,
    client,
    model: str = DEFAULT_EMBEDDING_MODEL,
) -> list[float]:
    if not text or not text.strip():
        raise ValueError("text must not be empty")
    response = await client.embeddings.create(
        input=text.strip(),
        model=model,
    )
    return response.data[0].embedding


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def chunk_text(
    text: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[str]:
    """Split text into chunks with overlap.

    Walking-window algorithm:
        - Start at index 0, take `chunk_size` chars
        - Step forward by `chunk_size - chunk_overlap`
        - Repeat until end of text

    Overlap helps preserve context across chunk boundaries — a sentence
    split between two chunks is partially repeated.
    """
    if not text or not text.strip():
        return []
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if chunk_overlap < 0:
        raise ValueError("chunk_overlap must be non-negative")
    if chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be less than chunk_size")

    text = text.strip()
    if len(text) <= chunk_size:
        return [text]

    step = chunk_size - chunk_overlap
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end == len(text):
            break
        start += step

    return chunks


async def embed_chunks(
    chunks: list[str],
    client,
    max_concurrency: int = 5,
) -> list[list[float]]:
    """Embed a list of chunks in parallel."""
    if not chunks:
        return []

    semaphore = asyncio.Semaphore(max_concurrency)

    async def _bounded(text: str) -> list[float]:
        async with semaphore:
            return await get_embedding(text, client)

    return await asyncio.gather(*[_bounded(c) for c in chunks])


# ---------------------------------------------------------------------------
# Chunk record + RAGStore
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    """A single indexed text chunk with metadata."""
    text: str
    source: str           # file path or document ID
    chunk_index: int      # 0-based position within the source
    embedding: list[float] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Chunk":
        return cls(
            text=data["text"],
            source=data["source"],
            chunk_index=data["chunk_index"],
            embedding=data.get("embedding", []),
        )


@dataclass
class RAGStore:
    """A persistent index of embedded chunks.

    Disk format (JSON):
        {
            "chunks": [
                {"text": "...", "source": "readme.md", "chunk_index": 0,
                 "embedding": [0.1, ...]},
                ...
            ]
        }
    """
    path: Optional[str] = None
    chunks: list[Chunk] = field(default_factory=list)

    @classmethod
    def load(cls, path: str) -> "RAGStore":
        if not os.path.exists(path):
            return cls(path=path)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(
            path=path,
            chunks=[Chunk.from_dict(d) for d in data.get("chunks", [])],
        )

    def save(self) -> None:
        if self.path is None:
            return
        data = {"chunks": [c.to_dict() for c in self.chunks]}
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def add_chunks(self, chunks: list[Chunk]) -> None:
        for c in chunks:
            if not c.embedding:
                raise ValueError(
                    f"Chunk for source={c.source!r} index={c.chunk_index} "
                    "has no embedding"
                )
        self.chunks.extend(chunks)

    def search(
        self,
        query_embedding: list[float],
        top_k: int = DEFAULT_TOP_K,
    ) -> list[tuple[Chunk, float]]:
        """Return [(chunk, score), ...] sorted by descending similarity."""
        if not self.chunks:
            return []
        scored = [
            (c, cosine_similarity(query_embedding, c.embedding))
            for c in self.chunks
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]


# ---------------------------------------------------------------------------
# Ingestion pipeline
# ---------------------------------------------------------------------------

async def ingest_document(
    text: str,
    source: str,
    store: RAGStore,
    client,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> int:
    """Chunk a document, embed all chunks, add to the store. Returns count."""
    if not text or not text.strip():
        raise ValueError("text must not be empty")
    if not source or not source.strip():
        raise ValueError("source must not be empty")

    pieces = chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    if not pieces:
        return 0

    embeddings = await embed_chunks(pieces, client)

    chunks = [
        Chunk(
            text=piece,
            source=source.strip(),
            chunk_index=i,
            embedding=emb,
        )
        for i, (piece, emb) in enumerate(zip(pieces, embeddings))
    ]
    store.add_chunks(chunks)
    return len(chunks)


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

async def retrieve(
    query: str,
    store: RAGStore,
    client,
    top_k: int = DEFAULT_TOP_K,
) -> list[tuple[Chunk, float]]:
    """Embed the query, return top_k matching chunks."""
    if not query or not query.strip():
        raise ValueError("query must not be empty")
    if not store.chunks:
        return []

    query_emb = await get_embedding(query, client)
    return store.search(query_emb, top_k=top_k)


# ---------------------------------------------------------------------------
# Augmented generation
# ---------------------------------------------------------------------------

def _build_context(retrieved: list[tuple[Chunk, float]]) -> str:
    """Format retrieved chunks as a context block for the LLM prompt."""
    parts = []
    for chunk, score in retrieved:
        header = (
            f"--- chunk #{chunk.chunk_index} "
            f"(dosya: {chunk.source}, benzerlik: {score:.3f}) ---"
        )
        parts.append(f"{header}\n{chunk.text}")
    return "\n\n".join(parts)


async def answer_with_rag(
    query: str,
    store: RAGStore,
    client,
    model: str = DEFAULT_MODEL,
    top_k: int = DEFAULT_TOP_K,
    temperature: float = DEFAULT_TEMPERATURE,
) -> dict:
    """Run a full RAG turn: retrieve + generate.

    Returns:
        {
            "answer": str,
            "citations": [
                {"source": "...", "chunk_index": N, "score": float},
                ...
            ],
        }
    """
    if not query or not query.strip():
        raise ValueError("query must not be empty")

    retrieved = await retrieve(query, store, client, top_k=top_k)

    if not retrieved:
        return {
            "answer": "Henüz indekslenmiş bir doküman yok, cevap veremiyorum.",
            "citations": [],
        }

    context = _build_context(retrieved)

    try:
        response = await client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": (
                        f"Kaynak parçalar:\n\n{context}\n\n"
                        f"Soru: {query.strip()}"
                    ),
                },
            ],
            temperature=temperature,
        )
    except Exception as e:
        raise RAGError(f"API call failed: {e}") from e

    answer = response.choices[0].message.content
    if answer is None:
        raise RAGError("Model returned empty content")

    citations = [
        {
            "source": chunk.source,
            "chunk_index": chunk.chunk_index,
            "score": round(score, 3),
        }
        for chunk, score in retrieved
    ]

    return {"answer": answer.strip(), "citations": citations}


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY is required.")
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rag",
        description="Doküman tabanlı RAG asistanı.",
    )
    parser.add_argument("--store", default="rag.json", help="RAG indeks dosyası")
    parser.add_argument("--ingest", help="İndekslenecek doküman dosyası (md/txt)")
    parser.add_argument("--query", help="Cevaplanacak soru")
    parser.add_argument("--top-k", type=int, default=DEFAULT_TOP_K)
    parser.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE)
    parser.add_argument("--chunk-overlap", type=int, default=DEFAULT_CHUNK_OVERLAP)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    return parser


async def _run(args) -> int:
    if not args.ingest and not args.query:
        print("Error: --ingest veya --query gerekli", file=sys.stderr)
        return 2

    client = build_client()
    store = RAGStore.load(args.store)

    if args.ingest:
        if not os.path.exists(args.ingest):
            print(f"Error: dosya bulunamadı: {args.ingest}", file=sys.stderr)
            return 1
        with open(args.ingest, "r", encoding="utf-8") as f:
            text = f.read()
        try:
            count = await ingest_document(
                text,
                source=args.ingest,
                store=store,
                client=client,
                chunk_size=args.chunk_size,
                chunk_overlap=args.chunk_overlap,
            )
        except (RAGError, ValueError) as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
            return 1
        store.save()
        print(json.dumps({
            "status": "ingested",
            "source": args.ingest,
            "chunks_added": count,
            "total_chunks": len(store.chunks),
        }, ensure_ascii=False, indent=2))

    if args.query:
        try:
            result = await answer_with_rag(
                args.query,
                store=store,
                client=client,
                model=args.model,
                top_k=args.top_k,
            )
        except (RAGError, ValueError) as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))

    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
