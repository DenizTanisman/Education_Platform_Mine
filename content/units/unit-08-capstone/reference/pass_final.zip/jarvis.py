"""
M8 — Capstone: Mini Jarvis
A personal assistant that combines M1-M7 capabilities.

Architecture:
    JarvisStore         — orchestrates memory, RAG, and tasks
        ├─ MemoryStore  (M6)  — facts + conversation
        ├─ RAGStore     (M7)  — chunked documents
        └─ TaskStore    (M1)  — SQLite-backed tasks

    ToolRegistry        — 6 tools wired to stores
        - remember_fact / recall_fact / search_memory   (memory)
        - add_task / list_tasks                         (tasks)
        - search_documents                              (RAG)

    run_jarvis(...)     — agent loop with full state plumbing

Public API (used by tests):
    cosine_similarity, get_embedding, chunk_text     — same as M6/M7
    Chunk, Task, MemoryStore, RAGStore, TaskStore
    JarvisStore                                       — orchestrator
    Tool, ToolRegistry                                — same as M5
    JarvisError                                       — exception

    run_jarvis(message, store, client, max_iters=5)  — async, returns str
    ingest_document_into(text, source, store, client) — async, returns int

CLI usage:
    python jarvis.py --message "Adım Deniz, İstanbul'da yaşıyorum"
    python jarvis.py --ingest readme.md
    python jarvis.py --message "Dokümanda RAG nasıl tanımlanıyor?"
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import math
import os
import sqlite3
import sys
from dataclasses import dataclass, field, asdict
from typing import Any, Awaitable, Callable, Optional

from openai import AsyncOpenAI
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
DEFAULT_MAX_ITERS = 6
DEFAULT_CHUNK_SIZE = 800
DEFAULT_CHUNK_OVERLAP = 100
DEFAULT_TOP_K = 3
DEFAULT_TEMPERATURE = 0.0

SYSTEM_PROMPT = (
    "Sen Jarvis adlı kişisel bir asistansın. Kullanıcının görevlerini, "
    "tercihlerini ve indekslenmiş dokümanlarını yönetiyorsun. "
    "Önemli kullanıcı bilgilerini remember_fact ile sakla. "
    "Görev eklerken add_task, listelerken list_tasks kullan. "
    "Doküman içeriğine dair sorularda search_documents kullan ve "
    "kaynak göster. Geçmiş konuşma için search_memory kullan. "
    "Cevaplarını Türkçe ve kısa tut."
)

logger = logging.getLogger("jarvis")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class JarvisError(Exception):
    pass


# ---------------------------------------------------------------------------
# Vector math (M6 / M7)
# ---------------------------------------------------------------------------

def cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        raise ValueError(f"Vector lengths differ: {len(a)} vs {len(b)}")
    if not a:
        raise ValueError("Vectors must not be empty")
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def get_embedding(text: str, client, model: str = DEFAULT_EMBEDDING_MODEL) -> list[float]:
    if not text or not text.strip():
        raise ValueError("text must not be empty")
    response = await client.embeddings.create(input=text.strip(), model=model)
    return response.data[0].embedding


# ---------------------------------------------------------------------------
# Chunking (M7)
# ---------------------------------------------------------------------------

def chunk_text(
    text: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> list[str]:
    if not text or not text.strip():
        return []
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if chunk_overlap < 0:
        raise ValueError("chunk_overlap must be non-negative")
    if chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be less than chunk_size")

    text = text.strip()
    if len(text) <= chunk_size:
        return [text]

    step = chunk_size - chunk_overlap
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end == len(text):
            break
        start += step
    return chunks


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Chunk:
    text: str
    source: str
    chunk_index: int
    embedding: list[float] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "Chunk":
        return cls(
            text=data["text"],
            source=data["source"],
            chunk_index=data["chunk_index"],
            embedding=data.get("embedding", []),
        )


@dataclass
class Task:
    id: int
    title: str
    done: bool = False


# ---------------------------------------------------------------------------
# Stores
# ---------------------------------------------------------------------------

@dataclass
class MemoryStore:
    """Facts + conversation history (M6)."""
    facts: dict[str, str] = field(default_factory=dict)
    conversation: list[dict] = field(default_factory=list)

    def remember_fact(self, key: str, value: str) -> None:
        if not key or not key.strip():
            raise ValueError("key must not be empty")
        self.facts[key.strip()] = value

    def recall_fact(self, key: str) -> Optional[str]:
        return self.facts.get(key.strip()) if key else None


@dataclass
class RAGStore:
    """Chunk index for documents (M7)."""
    chunks: list[Chunk] = field(default_factory=list)

    def add_chunks(self, chunks: list[Chunk]) -> None:
        for c in chunks:
            if not c.embedding:
                raise ValueError(
                    f"Chunk for source={c.source!r} index={c.chunk_index} has no embedding"
                )
        self.chunks.extend(chunks)

    def search(self, query_embedding: list[float], top_k: int = DEFAULT_TOP_K) -> list[tuple[Chunk, float]]:
        if not self.chunks:
            return []
        scored = [
            (c, cosine_similarity(query_embedding, c.embedding))
            for c in self.chunks
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]


class TaskStore:
    """SQLite-backed task list (M1).

    Uses an in-memory connection by default (`:memory:`). Tests use this
    so they don't touch disk. CLI passes a file path.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id    INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                done  INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        self.conn.commit()

    def add_task(self, title: str) -> Task:
        if not title or not title.strip():
            raise ValueError("title must not be empty")
        cursor = self.conn.execute(
            "INSERT INTO tasks (title, done) VALUES (?, 0)",
            (title.strip(),),
        )
        self.conn.commit()
        return Task(id=cursor.lastrowid, title=title.strip(), done=False)

    def list_tasks(self, done: Optional[bool] = None) -> list[Task]:
        if done is None:
            rows = self.conn.execute(
                "SELECT id, title, done FROM tasks ORDER BY id"
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT id, title, done FROM tasks WHERE done=? ORDER BY id",
                (1 if done else 0,),
            ).fetchall()
        return [Task(id=r["id"], title=r["title"], done=bool(r["done"])) for r in rows]

    def close(self) -> None:
        self.conn.close()


# ---------------------------------------------------------------------------
# JarvisStore — orchestrator
# ---------------------------------------------------------------------------

@dataclass
class JarvisStore:
    """Composite store: memory + rag + tasks."""
    memory: MemoryStore = field(default_factory=MemoryStore)
    rag: RAGStore = field(default_factory=RAGStore)
    tasks: TaskStore = field(default_factory=lambda: TaskStore(":memory:"))

    @classmethod
    def fresh(cls) -> "JarvisStore":
        """Build a fresh in-memory store. Used by tests."""
        return cls()


# ---------------------------------------------------------------------------
# Tool input schemas
# ---------------------------------------------------------------------------

class RememberFactInput(BaseModel):
    key: str = Field(description="Bilgi anahtarı, örn: 'name', 'home_city'")
    value: str = Field(description="Bilginin değeri")


class RecallFactInput(BaseModel):
    key: str = Field(description="Aranacak bilgi anahtarı")


class SearchMemoryInput(BaseModel):
    query: str = Field(description="Geçmiş konuşmalarda aranacak metin")


class AddTaskInput(BaseModel):
    title: str = Field(description="Görev başlığı, örn: 'Kitap oku'")


class ListTasksInput(BaseModel):
    done: Optional[bool] = Field(
        default=None,
        description="True=tamamlananlar, False=bekleyenler, None=hepsi",
    )


class SearchDocumentsInput(BaseModel):
    query: str = Field(description="Dokümanlarda aranacak soru veya metin")


# ---------------------------------------------------------------------------
# Tool dataclass + registry (M5 ile aynı)
# ---------------------------------------------------------------------------

@dataclass
class Tool:
    name: str
    description: str
    input_schema: type[BaseModel]
    handler: Callable[[BaseModel], Awaitable[Any]]

    def to_openai_format(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema.model_json_schema(),
            },
        }


@dataclass
class ToolRegistry:
    tools: dict[str, Tool] = field(default_factory=dict)

    def register(self, tool: Tool) -> None:
        if tool.name in self.tools:
            raise ValueError(f"Tool '{tool.name}' already registered")
        self.tools[tool.name] = tool

    def to_openai_list(self) -> list[dict]:
        return [t.to_openai_format() for t in self.tools.values()]

    async def call(self, name: str, arguments: dict) -> Any:
        if name not in self.tools:
            raise JarvisError(f"Unknown tool: {name}")
        tool = self.tools[name]
        try:
            parsed = tool.input_schema.model_validate(arguments)
        except Exception as e:
            raise JarvisError(f"Invalid arguments for {name}: {e}") from e
        return await tool.handler(parsed)


# ---------------------------------------------------------------------------
# Tool registry factory
# ---------------------------------------------------------------------------

def build_jarvis_registry(store: JarvisStore, client) -> ToolRegistry:
    """Build a registry with all 6 tools wired to the given JarvisStore."""
    registry = ToolRegistry()

    # --- Memory tools (M6) -------------------------------------------------

    async def _remember(input: RememberFactInput) -> dict:
        store.memory.remember_fact(input.key, input.value)
        return {"status": "saved", "key": input.key, "value": input.value}

    async def _recall(input: RecallFactInput) -> dict:
        v = store.memory.recall_fact(input.key)
        return {"key": input.key, "found": v is not None, "value": v}

    async def _search_memory(input: SearchMemoryInput) -> dict:
        # Search through stored conversation: embed query, score each user msg
        if not store.memory.conversation:
            return {"results": []}
        try:
            query_emb = await get_embedding(input.query, client)
        except Exception as e:
            return {"error": f"Embedding failed: {e}"}

        scored = []
        for msg in store.memory.conversation:
            if msg.get("role") != "user":
                continue
            content = msg.get("content", "")
            if not content:
                continue
            # We don't pre-embed conversation; embed on the fly (small N)
            try:
                emb = await get_embedding(content, client)
            except Exception:
                continue
            scored.append({
                "text": content,
                "score": cosine_similarity(query_emb, emb),
            })
        scored.sort(key=lambda x: x["score"], reverse=True)
        return {"results": scored[:DEFAULT_TOP_K]}

    # --- Task tools (M1) ---------------------------------------------------

    async def _add_task(input: AddTaskInput) -> dict:
        task = store.tasks.add_task(input.title)
        return {"id": task.id, "title": task.title, "status": "added"}

    async def _list_tasks(input: ListTasksInput) -> dict:
        tasks = store.tasks.list_tasks(done=input.done)
        return {
            "count": len(tasks),
            "tasks": [{"id": t.id, "title": t.title, "done": t.done} for t in tasks],
        }

    # --- RAG tool (M7) -----------------------------------------------------

    async def _search_documents(input: SearchDocumentsInput) -> dict:
        if not store.rag.chunks:
            return {"results": []}
        try:
            query_emb = await get_embedding(input.query, client)
        except Exception as e:
            return {"error": f"Embedding failed: {e}"}
        retrieved = store.rag.search(query_emb, top_k=DEFAULT_TOP_K)
        return {
            "results": [
                {
                    "text": c.text,
                    "source": c.source,
                    "chunk_index": c.chunk_index,
                    "score": round(score, 3),
                }
                for c, score in retrieved
            ],
        }

    # --- Register all ------------------------------------------------------

    registry.register(Tool(
        name="remember_fact",
        description="Bir kullanıcı bilgisini kalıcı olarak kaydet",
        input_schema=RememberFactInput,
        handler=_remember,
    ))
    registry.register(Tool(
        name="recall_fact",
        description="Daha önce kaydedilmiş bir bilgiyi hatırla",
        input_schema=RecallFactInput,
        handler=_recall,
    ))
    registry.register(Tool(
        name="search_memory",
        description="Geçmiş konuşmalarda semantik arama yap",
        input_schema=SearchMemoryInput,
        handler=_search_memory,
    ))
    registry.register(Tool(
        name="add_task",
        description="Görev listesine yeni bir görev ekle",
        input_schema=AddTaskInput,
        handler=_add_task,
    ))
    registry.register(Tool(
        name="list_tasks",
        description="Görev listesini döndür (tüm/tamamlanan/bekleyen)",
        input_schema=ListTasksInput,
        handler=_list_tasks,
    ))
    registry.register(Tool(
        name="search_documents",
        description="İndekslenmiş dokümanlarda semantik arama yap",
        input_schema=SearchDocumentsInput,
        handler=_search_documents,
    ))

    return registry


# ---------------------------------------------------------------------------
# Document ingestion (M7 pattern)
# ---------------------------------------------------------------------------

async def ingest_document_into(
    text: str,
    source: str,
    store: JarvisStore,
    client,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    chunk_overlap: int = DEFAULT_CHUNK_OVERLAP,
) -> int:
    if not text or not text.strip():
        raise ValueError("text must not be empty")
    if not source or not source.strip():
        raise ValueError("source must not be empty")

    pieces = chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    if not pieces:
        return 0

    # Embed all chunks in parallel (M3 pattern)
    semaphore = asyncio.Semaphore(5)

    async def _bounded(t):
        async with semaphore:
            return await get_embedding(t, client)

    embeddings = await asyncio.gather(*[_bounded(p) for p in pieces])

    chunks = [
        Chunk(text=p, source=source.strip(), chunk_index=i, embedding=e)
        for i, (p, e) in enumerate(zip(pieces, embeddings))
    ]
    store.rag.add_chunks(chunks)
    return len(chunks)


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY is required.")
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# Main agent loop (M5 + M6 patterns combined)
# ---------------------------------------------------------------------------

async def run_jarvis(
    user_message: str,
    store: JarvisStore,
    client,
    model: str = DEFAULT_MODEL,
    max_iters: int = DEFAULT_MAX_ITERS,
    temperature: float = DEFAULT_TEMPERATURE,
) -> str:
    """Run one turn of Jarvis.

    Persists the conversation to store.memory. Returns the final text.
    """
    if not user_message or not user_message.strip():
        raise ValueError("user_message must not be empty")

    registry = build_jarvis_registry(store, client)
    tools = registry.to_openai_list()

    facts_summary = (
        "\n".join(f"- {k}: {v}" for k, v in store.memory.facts.items())
        if store.memory.facts else "(henüz hatırlanan bir şey yok)"
    )
    indexed_summary = (
        f"İndekslenmiş doküman parçaları: {len(store.rag.chunks)} chunk"
        if store.rag.chunks else "(indekslenmiş doküman yok)"
    )

    messages: list[dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "system",
            "content": (
                f"Hatırlanan bilgiler:\n{facts_summary}\n\n{indexed_summary}"
            ),
        },
    ]
    messages.extend(store.memory.conversation[-20:])
    user_msg = {"role": "user", "content": user_message.strip()}
    messages.append(user_msg)

    for iteration in range(1, max_iters + 1):
        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=temperature,
            )
        except Exception as e:
            raise JarvisError(f"API call failed: {e}") from e

        message = response.choices[0].message
        tool_calls = message.tool_calls or []

        if not tool_calls:
            content = message.content
            if content is None:
                raise JarvisError("Model returned neither tool calls nor content")
            answer = content.strip()

            # Persist conversation
            store.memory.conversation.append(user_msg)
            store.memory.conversation.append({"role": "assistant", "content": answer})
            return answer

        # Append assistant's tool_call message
        messages.append({
            "role": "assistant",
            "content": message.content,
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in tool_calls
            ],
        })

        # Execute tools in parallel
        async def _execute(tc):
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError as e:
                return tc.id, {"error": f"JSON parse failed: {e}"}
            try:
                result = await registry.call(tc.function.name, args)
                return tc.id, result
            except JarvisError as e:
                return tc.id, {"error": str(e)}

        results = await asyncio.gather(*[_execute(tc) for tc in tool_calls])

        for tool_call_id, result in results:
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": json.dumps(result, ensure_ascii=False),
            })

    raise JarvisError(
        f"Jarvis did not finish within {max_iters} iterations."
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="jarvis",
        description="Mini Jarvis: bellekli, RAG'li, görev yönetimli kişisel asistan.",
    )
    parser.add_argument("--message", help="Jarvis'e sorulacak/söylenecek")
    parser.add_argument("--ingest", help="İndekslenecek doküman dosyası")
    parser.add_argument("--max-iters", type=int, default=DEFAULT_MAX_ITERS)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    return parser


async def _run(args) -> int:
    if not args.message and not args.ingest:
        print("Error: --message veya --ingest gerekli", file=sys.stderr)
        return 2

    client = build_client()
    store = JarvisStore.fresh()  # CLI demo — process'ler arası persist yok

    if args.ingest:
        if not os.path.exists(args.ingest):
            print(f"Error: dosya bulunamadı: {args.ingest}", file=sys.stderr)
            return 1
        with open(args.ingest, "r", encoding="utf-8") as f:
            text = f.read()
        try:
            count = await ingest_document_into(text, args.ingest, store, client)
        except (JarvisError, ValueError) as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
            return 1
        print(json.dumps({
            "status": "ingested",
            "chunks_added": count,
            "source": args.ingest,
        }, ensure_ascii=False, indent=2))

    if args.message:
        try:
            answer = await run_jarvis(args.message, store, client, max_iters=args.max_iters, model=args.model)
        except (JarvisError, ValueError) as e:
            print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
            return 1
        print(json.dumps({"answer": answer}, ensure_ascii=False, indent=2))

    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
