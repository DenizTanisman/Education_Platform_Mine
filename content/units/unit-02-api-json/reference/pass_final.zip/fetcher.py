"""
M2 — API ve JSON
Reference solution: a resilient HTTP fetcher.

Public API (used by tests):
    fetch_with_retry(url: str, ..., session=None) -> dict | list
        Make a GET request with exponential backoff retries. Returns parsed
        JSON. Raises FetchError after max retries.

    save_to_json(data, path: str) -> None
        Pretty-print JSON to file with UTF-8 + ensure_ascii=False.

    fetch_and_save(url: str, output_path: str, **kwargs) -> dict
        End-to-end: fetch -> save. Returns metadata dict.

CLI usage:
    python fetcher.py --url https://restcountries.com/v3.1/name/turkey \\
                      --output turkey.json
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from typing import Optional, Union

import requests


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MAX_RETRIES = 3
DEFAULT_TIMEOUT = 10
DEFAULT_BACKOFF_BASE = 1.0  # seconds; 1, 2, 4 for retries 1, 2, 3
DEFAULT_USER_AGENT = "iau-ai-course-m2/1.0"

# These HTTP status codes indicate transient errors worth retrying.
# 4xx errors (except 429) are caller mistakes — retrying won't help.
RETRYABLE_STATUS = {429, 500, 502, 503, 504}

logger = logging.getLogger("fetcher")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class FetchError(Exception):
    """Raised when fetch_with_retry exhausts retries or hits a fatal error."""
    pass


# ---------------------------------------------------------------------------
# Core fetch logic
# ---------------------------------------------------------------------------

def fetch_with_retry(
    url: str,
    max_retries: int = DEFAULT_MAX_RETRIES,
    timeout: int = DEFAULT_TIMEOUT,
    backoff_base: float = DEFAULT_BACKOFF_BASE,
    session: Optional[requests.Session] = None,
) -> Union[dict, list]:
    """Fetch a URL with exponential backoff. Returns parsed JSON.

    Retries on:
      - Connection errors (DNS, timeout, refused)
      - HTTP 5xx errors
      - HTTP 429 (rate limited)

    Does NOT retry on:
      - HTTP 4xx errors other than 429 (your bug, not theirs)
      - JSON decode errors

    Backoff: 2^(attempt-1) * backoff_base seconds. With base=1.0, that's
    1s before retry 1, 2s before retry 2, 4s before retry 3.

    Raises:
        FetchError: After max_retries failures, or on non-retryable HTTP error,
                    or on JSON decode failure.
    """
    if not url:
        raise ValueError("url must not be empty")
    if max_retries < 1:
        raise ValueError("max_retries must be >= 1")

    http = session or requests.Session()
    headers = {"User-Agent": DEFAULT_USER_AGENT, "Accept": "application/json"}

    last_error: Optional[str] = None

    for attempt in range(1, max_retries + 1):
        try:
            logger.info("GET %s (attempt %d/%d)", url, attempt, max_retries)
            response = http.get(url, headers=headers, timeout=timeout)

            # Retryable HTTP status?
            if response.status_code in RETRYABLE_STATUS:
                last_error = f"HTTP {response.status_code}"
                logger.warning(
                    "Retryable status %d on attempt %d", response.status_code, attempt
                )
                if attempt < max_retries:
                    sleep_for = backoff_base * (2 ** (attempt - 1))
                    logger.info("Backing off %.1fs", sleep_for)
                    time.sleep(sleep_for)
                continue

            # Other 4xx — don't retry, raise immediately
            if 400 <= response.status_code < 500:
                raise FetchError(
                    f"HTTP {response.status_code}: {response.reason} (not retried)"
                )

            # 2xx success — try to parse JSON
            response.raise_for_status()
            try:
                return response.json()
            except json.JSONDecodeError as e:
                raise FetchError(f"Response was not valid JSON: {e}") from e

        except requests.exceptions.RequestException as e:
            # Connection errors, timeouts, etc. — retry
            last_error = f"{e.__class__.__name__}: {e}"
            logger.warning("Network error on attempt %d: %s", attempt, last_error)
            if attempt < max_retries:
                sleep_for = backoff_base * (2 ** (attempt - 1))
                logger.info("Backing off %.1fs", sleep_for)
                time.sleep(sleep_for)
            continue

    # Exhausted retries
    raise FetchError(
        f"Failed after {max_retries} attempts. Last error: {last_error}"
    )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def save_to_json(data: Union[dict, list], path: str) -> None:
    """Save JSON-serializable data to a file with UTF-8 + pretty-print."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info("Saved %d bytes to %s", _approx_size(data), path)


def _approx_size(data) -> int:
    """Rough size estimate (for logging, not exact)."""
    return len(json.dumps(data, ensure_ascii=False))


# ---------------------------------------------------------------------------
# Convenience wrapper
# ---------------------------------------------------------------------------

def fetch_and_save(
    url: str,
    output_path: str,
    **kwargs,
) -> dict:
    """End-to-end: fetch URL and save JSON to disk. Returns metadata."""
    data = fetch_with_retry(url, **kwargs)
    save_to_json(data, output_path)
    return {
        "url": url,
        "output": output_path,
        "size_bytes": _approx_size(data),
        "type": type(data).__name__,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fetcher",
        description="Bir public API'den JSON çekip dosyaya kaydeden araç.",
    )
    parser.add_argument(
        "--url",
        required=True,
        help="Çekilecek URL (örn: https://restcountries.com/v3.1/name/turkey)",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Çıktı JSON dosyası yolu",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=DEFAULT_MAX_RETRIES,
        help=f"Maksimum deneme sayısı (varsayılan: {DEFAULT_MAX_RETRIES})",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=DEFAULT_TIMEOUT,
        help=f"İstek timeout süresi saniye (varsayılan: {DEFAULT_TIMEOUT})",
    )
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        meta = fetch_and_save(
            args.url,
            args.output,
            max_retries=args.retries,
            timeout=args.timeout,
        )
        print(json.dumps(meta, ensure_ascii=False, indent=2))
        return 0
    except FetchError as e:
        logger.error("Fetch failed: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1
    except ValueError as e:
        logger.error("Invalid argument: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
