"""
M6 — Memory ile Stateful Agent
Reference solution: a stateful assistant with three layers of memory.

Memory layers:
    1. Conversation history    — multi-turn messages persisted to disk
    2. Facts (key-value)       — durable user preferences ("home_city" -> "İstanbul")
    3. Semantic memory         — embedded message archive, cosine similarity recall

Public API (used by tests):
    MemoryStore                — persistent storage class (load/save/methods)
    cosine_similarity(a, b)    — vector similarity
    get_embedding(text, client) -> list[float]   (async)
    AssistantError (exception)

    run_assistant(user_message, client, store, max_iters=5) (async)
        Run one turn of the conversation. Loads/saves state automatically.

CLI usage:
    python assistant.py --message "Adım Deniz" --store memory.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import math
import os
import sys
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional

from openai import AsyncOpenAI
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-small"
DEFAULT_MAX_ITERS = 5
DEFAULT_TEMPERATURE = 0.0
DEFAULT_TOP_K = 3  # how many memories to recall

SYSTEM_PROMPT = (
    "Sen kullanıcıyı tanıyan, geçmişi hatırlayan kişisel bir asistansın. "
    "Önemli kullanıcı bilgilerini (isim, şehir, tercih) öğrendiğinde "
    "remember_fact aracını kullan. Geçmiş bir bilgiyi sorulduğunda "
    "recall_fact veya search_memory kullan. Cevaplarını Türkçe ver, kısa tut."
)

logger = logging.getLogger("assistant")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class AssistantError(Exception):
    """Raised when the assistant fails."""
    pass


# ---------------------------------------------------------------------------
# Vector math (cosine similarity)
# ---------------------------------------------------------------------------

def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors.

    Returns a float in [-1, 1]. For OpenAI embeddings (which are L2-normalized)
    this is equivalent to dot product but we use the full formula for clarity.
    """
    if len(a) != len(b):
        raise ValueError(f"Vector lengths differ: {len(a)} vs {len(b)}")
    if not a:
        raise ValueError("Vectors must not be empty")

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


async def get_embedding(
    text: str,
    client,
    model: str = DEFAULT_EMBEDDING_MODEL,
) -> list[float]:
    """Get an embedding vector for a piece of text via OpenAI API."""
    if not text or not text.strip():
        raise ValueError("text must not be empty")

    response = await client.embeddings.create(
        input=text.strip(),
        model=model,
    )
    return response.data[0].embedding


# ---------------------------------------------------------------------------
# Memory store
# ---------------------------------------------------------------------------

@dataclass
class MemoryStore:
    """File-backed persistent memory store.

    State layout on disk (JSON):
        {
            "facts": {"home_city": "İstanbul", "name": "Deniz"},
            "conversation": [{"role": "user", "content": "..."}],
            "memories": [
                {"text": "...", "embedding": [0.1, ...], "tags": []},
                ...
            ]
        }

    Tests pass an in-memory store (no path), so save() is a no-op there.
    """
    path: Optional[str] = None
    facts: dict[str, str] = field(default_factory=dict)
    conversation: list[dict] = field(default_factory=list)
    memories: list[dict] = field(default_factory=list)

    @classmethod
    def load(cls, path: str) -> "MemoryStore":
        """Load from JSON file. Returns a fresh store if file doesn't exist."""
        if not os.path.exists(path):
            return cls(path=path)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(
            path=path,
            facts=data.get("facts", {}),
            conversation=data.get("conversation", []),
            memories=data.get("memories", []),
        )

    def save(self) -> None:
        """Persist to JSON file. No-op if path is None (in-memory mode)."""
        if self.path is None:
            return
        data = {
            "facts": self.facts,
            "conversation": self.conversation,
            "memories": self.memories,
        }
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # -- Facts -------------------------------------------------------------

    def remember_fact(self, key: str, value: str) -> None:
        if not key or not key.strip():
            raise ValueError("key must not be empty")
        self.facts[key.strip()] = value

    def recall_fact(self, key: str) -> Optional[str]:
        return self.facts.get(key.strip()) if key else None

    # -- Semantic memory ---------------------------------------------------

    def add_memory(
        self,
        text: str,
        embedding: list[float],
        tags: Optional[list[str]] = None,
    ) -> None:
        if not text or not text.strip():
            raise ValueError("text must not be empty")
        if not embedding:
            raise ValueError("embedding must not be empty")
        self.memories.append({
            "text": text.strip(),
            "embedding": embedding,
            "tags": tags or [],
        })

    def search_memories(
        self,
        query_embedding: list[float],
        top_k: int = DEFAULT_TOP_K,
    ) -> list[dict]:
        """Return top_k memories sorted by cosine similarity descending.

        Each result has the original {text, embedding, tags} plus 'score'.
        """
        if not self.memories:
            return []
        scored = [
            {**m, "score": cosine_similarity(query_embedding, m["embedding"])}
            for m in self.memories
        ]
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]


# ---------------------------------------------------------------------------
# Tool input schemas
# ---------------------------------------------------------------------------

class RememberFactInput(BaseModel):
    key: str = Field(description="Bilgi anahtarı, örn: 'home_city', 'name'")
    value: str = Field(description="Bilginin değeri, örn: 'İstanbul'")


class RecallFactInput(BaseModel):
    key: str = Field(description="Aranacak bilgi anahtarı")


class SearchMemoryInput(BaseModel):
    query: str = Field(description="Geçmiş konuşmalarda aranacak metin")


# ---------------------------------------------------------------------------
# Tool dataclass + registry (M5 ile aynı pattern, kısaltılmış)
# ---------------------------------------------------------------------------

@dataclass
class Tool:
    name: str
    description: str
    input_schema: type[BaseModel]
    handler: Callable[[BaseModel], Awaitable[Any]]

    def to_openai_format(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.input_schema.model_json_schema(),
            },
        }


@dataclass
class ToolRegistry:
    tools: dict[str, Tool] = field(default_factory=dict)

    def register(self, tool: Tool) -> None:
        if tool.name in self.tools:
            raise ValueError(f"Tool '{tool.name}' already registered")
        self.tools[tool.name] = tool

    def to_openai_list(self) -> list[dict]:
        return [t.to_openai_format() for t in self.tools.values()]

    async def call(self, name: str, arguments: dict) -> Any:
        if name not in self.tools:
            raise AssistantError(f"Unknown tool: {name}")
        tool = self.tools[name]
        try:
            parsed = tool.input_schema.model_validate(arguments)
        except Exception as e:
            raise AssistantError(f"Invalid arguments for {name}: {e}") from e
        return await tool.handler(parsed)


# ---------------------------------------------------------------------------
# Tool handler factory (closures over MemoryStore + client)
# ---------------------------------------------------------------------------

def build_memory_registry(store: MemoryStore, client) -> ToolRegistry:
    """Build a tool registry with memory tools bound to a specific store."""
    registry = ToolRegistry()

    async def _remember(input: RememberFactInput) -> dict:
        store.remember_fact(input.key, input.value)
        return {"status": "saved", "key": input.key, "value": input.value}

    async def _recall(input: RecallFactInput) -> dict:
        value = store.recall_fact(input.key)
        if value is None:
            return {"key": input.key, "found": False}
        return {"key": input.key, "found": True, "value": value}

    async def _search(input: SearchMemoryInput) -> dict:
        if not store.memories:
            return {"results": []}
        try:
            query_emb = await get_embedding(input.query, client)
        except Exception as e:
            return {"error": f"Embedding failed: {e}"}
        results = store.search_memories(query_emb, top_k=DEFAULT_TOP_K)
        return {
            "results": [
                {"text": r["text"], "score": round(r["score"], 3)}
                for r in results
            ],
        }

    registry.register(Tool(
        name="remember_fact",
        description="Bir kullanıcı bilgisini kalıcı olarak kaydet",
        input_schema=RememberFactInput,
        handler=_remember,
    ))
    registry.register(Tool(
        name="recall_fact",
        description="Daha önce kaydedilmiş bir kullanıcı bilgisini hatırla",
        input_schema=RecallFactInput,
        handler=_recall,
    ))
    registry.register(Tool(
        name="search_memory",
        description="Geçmiş konuşma anılarında semantik arama yap",
        input_schema=SearchMemoryInput,
        handler=_search,
    ))

    return registry


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY is required.")
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# Assistant loop
# ---------------------------------------------------------------------------

async def run_assistant(
    user_message: str,
    client,
    store: MemoryStore,
    model: str = DEFAULT_MODEL,
    max_iters: int = DEFAULT_MAX_ITERS,
    temperature: float = DEFAULT_TEMPERATURE,
) -> str:
    """Run one turn of the assistant.

    Persists the conversation to the store. Returns the final assistant text.
    """
    if not user_message or not user_message.strip():
        raise ValueError("user_message must not be empty")

    registry = build_memory_registry(store, client)
    tools = registry.to_openai_list()

    # Compose messages: system + facts hint + prior conversation + new user msg
    facts_summary = (
        "\n".join(f"- {k}: {v}" for k, v in store.facts.items())
        if store.facts else "(henüz hatırlanan bir şey yok)"
    )
    messages: list[dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": f"Hatırlanan kullanıcı bilgileri:\n{facts_summary}"},
    ]
    # Carry forward previous turns (capped to last 20 to control context size)
    messages.extend(store.conversation[-20:])
    user_msg = {"role": "user", "content": user_message.strip()}
    messages.append(user_msg)

    for iteration in range(1, max_iters + 1):
        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice="auto",
                temperature=temperature,
            )
        except Exception as e:
            raise AssistantError(f"API call failed: {e}") from e

        message = response.choices[0].message
        tool_calls = message.tool_calls or []

        if not tool_calls:
            content = message.content
            if content is None:
                raise AssistantError("Model returned neither tool calls nor content")
            answer = content.strip()

            # Persist this turn into the conversation history
            store.conversation.append(user_msg)
            store.conversation.append({"role": "assistant", "content": answer})

            # Also add to semantic memory (user message embedding)
            try:
                emb = await get_embedding(user_message.strip(), client)
                store.add_memory(user_message.strip(), emb, tags=["user_msg"])
            except Exception as e:
                logger.warning("Failed to embed message for memory: %s", e)

            store.save()
            return answer

        # Append assistant's tool_call message
        messages.append({
            "role": "assistant",
            "content": message.content,
            "tool_calls": [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in tool_calls
            ],
        })

        # Execute tools in parallel
        async def _execute(tc):
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError as e:
                return tc.id, {"error": f"Argümanlar JSON değil: {e}"}
            try:
                result = await registry.call(tc.function.name, args)
                return tc.id, result
            except AssistantError as e:
                return tc.id, {"error": str(e)}

        results = await asyncio.gather(*[_execute(tc) for tc in tool_calls])

        for tool_call_id, result in results:
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": json.dumps(result, ensure_ascii=False),
            })

    raise AssistantError(
        f"Assistant did not finish within {max_iters} iterations."
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="assistant",
        description="Belleği olan bir kişisel asistan.",
    )
    parser.add_argument("--message", required=True)
    parser.add_argument("--store", default="memory.json", help="Bellek dosyası")
    parser.add_argument("--max-iters", type=int, default=DEFAULT_MAX_ITERS)
    parser.add_argument("--model", default=DEFAULT_MODEL)
    return parser


async def _run(args) -> int:
    client = build_client()
    store = MemoryStore.load(args.store)

    try:
        answer = await run_assistant(
            args.message,
            client,
            store,
            model=args.model,
            max_iters=args.max_iters,
        )
    except (AssistantError, ValueError) as e:
        logger.error("Assistant failed: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1

    print(json.dumps({
        "answer": answer,
        "facts_count": len(store.facts),
        "conversation_turns": len(store.conversation) // 2,
        "memories_count": len(store.memories),
    }, ensure_ascii=False, indent=2))
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
