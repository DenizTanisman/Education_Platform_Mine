"""
M4 — Structured Output ile Pydantic
Reference solution: a review information extractor.

Public API (used by tests):
    Sentiment (Enum)              — positive, neutral, negative
    Category (Enum)               — product, service, delivery, support, other
    ReviewAnalysis (BaseModel)    — the structured schema we extract
        rating: int (1-5)
        sentiment: Sentiment
        category: Category
        summary: str
        red_flags: list[str]

    extract_review(text, client, model=...) -> ReviewAnalysis (async)
        Single async extraction. Returns parsed Pydantic instance.

    extract_many(texts, client, max_concurrency=5) -> list[ReviewAnalysis]
        Parallel extraction with order preservation.

    save_analyses(reviews, analyses, path) -> None
        Save (review_text, analysis) pairs as JSON.

CLI usage:
    python extractor.py --input reviews.txt --output analyses.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from enum import Enum
from typing import Optional

from openai import AsyncOpenAI
from pydantic import BaseModel, Field, ValidationError


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"
DEFAULT_MAX_CONCURRENCY = 5
DEFAULT_TEMPERATURE = 0.0  # deterministic for extraction

SYSTEM_PROMPT = (
    "Sen kullanıcı yorumlarından yapısal bilgi çıkaran bir asistansın. "
    "Verilen yorumu analiz et ve verilen şemaya uygun JSON döndür. "
    "Tüm değerleri Türkçe yaz. red_flags listesi ürün/hizmetle ilgili "
    "ciddi sorunları içersin (gecikme, hasar, dolandırıcılık, sahte ürün vb.). "
    "Sorun yoksa boş liste döndür."
)

logger = logging.getLogger("extractor")


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class ExtractError(Exception):
    """Raised when extraction fails for any reason."""
    pass


# ---------------------------------------------------------------------------
# Schema definitions (Pydantic v2)
# ---------------------------------------------------------------------------

class Sentiment(str, Enum):
    """Overall emotional tone of the review."""
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"


class Category(str, Enum):
    """What aspect of the experience the review is about."""
    PRODUCT = "product"
    SERVICE = "service"
    DELIVERY = "delivery"
    SUPPORT = "support"
    OTHER = "other"


class ReviewAnalysis(BaseModel):
    """Structured output schema for a single review.

    Field order matters here: OpenAI structured outputs follows the
    declaration order. Use `description` so the model knows what to fill.
    """
    rating: int = Field(
        ge=1, le=5,
        description="Yıldız puanı tahmini (1=en kötü, 5=en iyi)",
    )
    sentiment: Sentiment = Field(
        description="Genel duygu tonu",
    )
    category: Category = Field(
        description="Yorum hangi konuyla ilgili",
    )
    summary: str = Field(
        description="2-3 cümlelik Türkçe özet",
    )
    red_flags: list[str] = Field(
        default_factory=list,
        description="Yorumda bahsedilen ciddi sorunlar (yoksa boş liste)",
    )


# ---------------------------------------------------------------------------
# Client construction
# ---------------------------------------------------------------------------

def build_client(api_key: Optional[str] = None) -> AsyncOpenAI:
    key = api_key or os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError(
            "OPENAI_API_KEY is required. "
            "Set it as an env var or pass api_key explicitly."
        )
    return AsyncOpenAI(api_key=key)


# ---------------------------------------------------------------------------
# Single extraction
# ---------------------------------------------------------------------------

async def extract_review(
    text: str,
    client,
    model: str = DEFAULT_MODEL,
    temperature: float = DEFAULT_TEMPERATURE,
) -> ReviewAnalysis:
    """Extract structured information from a single review.

    Uses chat.completions.parse with response_format=ReviewAnalysis. The
    SDK takes care of converting the Pydantic class to JSON schema and
    parsing the response back to an instance.

    Raises:
        ValueError: If text is empty.
        ExtractError: If the API call fails or parsing fails.
    """
    if not text or not text.strip():
        raise ValueError("review text must not be empty")

    try:
        response = await client.chat.completions.parse(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Yorum: {text.strip()}"},
            ],
            response_format=ReviewAnalysis,
            temperature=temperature,
        )
    except Exception as e:
        raise ExtractError(
            f"API call failed: {e}"
        ) from e

    try:
        parsed = response.choices[0].message.parsed
    except (AttributeError, IndexError) as e:
        raise ExtractError(
            f"Unexpected response shape: {e}"
        ) from e

    if parsed is None:
        # Some refusals or filter triggers leave parsed=None but content set
        refusal = getattr(response.choices[0].message, "refusal", None)
        if refusal:
            raise ExtractError(f"Model refused to respond: {refusal}")
        raise ExtractError("API returned no parsed content")

    return parsed


# ---------------------------------------------------------------------------
# Parallel orchestration
# ---------------------------------------------------------------------------

async def extract_many(
    texts: list[str],
    client,
    max_concurrency: int = DEFAULT_MAX_CONCURRENCY,
    **kwargs,
) -> list[ReviewAnalysis]:
    """Extract from many reviews concurrently.

    Returns analyses in the SAME ORDER as input texts. Concurrency is
    capped by an asyncio.Semaphore.
    """
    if not texts:
        return []

    semaphore = asyncio.Semaphore(max_concurrency)

    async def _bounded(text: str) -> ReviewAnalysis:
        async with semaphore:
            return await extract_review(text, client, **kwargs)

    tasks = [_bounded(t) for t in texts]
    return await asyncio.gather(*tasks)


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def save_analyses(
    texts: list[str],
    analyses: list[ReviewAnalysis],
    path: str,
) -> None:
    """Save (text, analysis) pairs as a JSON array.

    Uses Pydantic's model_dump() for clean JSON serialization. Enums
    serialize to their string values automatically.
    """
    if len(texts) != len(analyses):
        raise ValueError(
            f"texts ({len(texts)}) and analyses ({len(analyses)}) "
            "must be the same length"
        )

    records = [
        {
            "review": text,
            "analysis": analysis.model_dump(mode="json"),
        }
        for text, analysis in zip(texts, analyses)
    ]

    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="extractor",
        description="Kullanıcı yorumlarından yapısal bilgi çıkaran araç.",
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Her satırda bir yorum olan TXT dosyası",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Analiz çıktısının yazılacağı JSON dosyası",
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=DEFAULT_MAX_CONCURRENCY,
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
    )
    return parser


async def _run(args) -> int:
    with open(args.input, "r", encoding="utf-8") as f:
        texts = [line.strip() for line in f if line.strip()]

    if not texts:
        logger.error("No reviews found in %s", args.input)
        return 1

    logger.info(
        "Extracting from %d reviews with concurrency=%d, model=%s",
        len(texts), args.concurrency, args.model,
    )

    client = build_client()

    try:
        analyses = await extract_many(
            texts,
            client,
            max_concurrency=args.concurrency,
            model=args.model,
        )
    except (ExtractError, ValueError) as e:
        logger.error("Extraction failed: %s", e)
        print(json.dumps({"error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1

    save_analyses(texts, analyses, args.output)
    print(json.dumps({
        "count": len(analyses),
        "output": args.output,
        "categories": {
            cat.value: sum(1 for a in analyses if a.category == cat)
            for cat in Category
        },
    }, ensure_ascii=False, indent=2))
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    parser = build_parser()
    args = parser.parse_args(argv)
    return asyncio.run(_run(args))


if __name__ == "__main__":
    sys.exit(main())
